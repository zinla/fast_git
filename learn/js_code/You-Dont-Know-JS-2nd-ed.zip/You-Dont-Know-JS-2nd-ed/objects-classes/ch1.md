# You Don't Know JS Yet: Objects & Classes - 2nd Edition
# Chapter 1: TODO

| NOTE: |
| :--- |
| Work in progress |
