export { Point, point } from './Point';
